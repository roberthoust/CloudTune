import Foundation

class ImportState: ObservableObject {
    @Published var isImporting: Bool = false
}
